import rootReducer from '@/store/root/rootReducer'

export type GlobalStateType = ReturnType<typeof rootReducer>
