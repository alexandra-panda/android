export const rootGreenColor = 'rgb(8, 218, 95)'
